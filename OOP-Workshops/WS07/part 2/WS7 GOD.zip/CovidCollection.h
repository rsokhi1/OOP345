#ifndef SDDS_COVIDCOLLECTION_H_
#define SDDS_COVIDCOLLECTION_H_
#include <string>
#include <vector>
#include <list>
namespace sdds{
    struct Covid{
        std::string m_country{};
        std::string m_city{};
        std::string m_variant{};
        int m_noOfCases{};
        int m_year{};
        int m_deaths{};
    };
    

    class CovidCollection{
        std::vector<Covid*> m_covidList;
        std::string removeSpaces(std::string str);
    public:
        CovidCollection(const std::string filename);
        void display(std::ostream& ostr) const;
        //friend std::ostream& operator<<(std::ostream&, const Covid&);
        ~CovidCollection();

        void sort(std::string field);
        void cleanList();
        bool inCollection(std::string variant) const;
        std::list<Covid> getListForCountry(std::string country) const;
        std::list<Covid> getListForVariant(std::string variant) const;
    };
    std::ostream& operator<<(std::ostream&, const Covid&);
}

#endif // !SDDS_COVIDCOLLECTION_H_